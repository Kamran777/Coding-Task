export const environment = {
  production: false,
  apiUrl: 'https://localhost:44377/api/'
};
