export interface AuthenticationResponse {
  id: string;
  accessToken: string;
}
