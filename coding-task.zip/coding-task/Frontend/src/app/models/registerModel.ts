import { Role } from './role';

export class RegisterModel {
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  role: Role[] = [];
  password: string = '';
  age: number;
  country: string = '';
  userName: string = '';
}
