import { Role } from './role';

export class UserDto {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  roles: Role[];
  password: string;
  age: number;
  country: string;
  userName: string;
}
