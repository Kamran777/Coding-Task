export class ErrorModel {
  status: number;
  message: string;
}
