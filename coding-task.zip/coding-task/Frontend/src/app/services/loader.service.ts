import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class LoaderService {
  
  private httpLoading$ = new BehaviorSubject<boolean>(false);
  constructor() {}

  httpProgress(): Observable<boolean> {
    return this.httpLoading$.asObservable();
  }

  setHttpProgressStatus(inprogress: boolean) {
    this.httpLoading$.next(inprogress);
  }
}
