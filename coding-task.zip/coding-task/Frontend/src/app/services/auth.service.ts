import { UserDto } from './../models/userDto';
import { Role } from './../models/role';
import { RegisterModel } from 'src/app/models/registerModel';
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, BehaviorSubject } from 'rxjs';
import { AuthenticationRequest } from '../models/authenticationRequest';
import { AuthenticationResponse } from '../models/authenticationResponse';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private userDto: BehaviorSubject<UserDto> = new BehaviorSubject<UserDto>({} as any);
  private isLoggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private role: BehaviorSubject<string> = new BehaviorSubject<string>('');

  constructor(private apiService: ApiService, private router: Router) { 
    if (this.Token){
      this.isLoggedIn.next(true);
    }
    else{
      this.isLoggedIn.next(false);
    }

    if (this.User){
      if(this.User.roles){
        this.role.next(this.User.roles[0].name);
      }
    }
    else{
      this.role.next({} as any);
    }
  }

  register(userRegistration: RegisterModel): Observable<any> {
    return this.apiService.post<any>(userRegistration, 'auth/register');
  }

  requestToken(email: string, password: string): Observable<AuthenticationResponse> {
    var model: AuthenticationRequest = {
      email: email,
      password: password
    };
    return this.apiService.post<AuthenticationResponse>(model, "auth/login");
  }

  completeAuthentication(id: string, token: string): void {
    localStorage.setItem('token', "Bearer " + token);
    this.isLoggedIn.next(true);
    this.apiService.get<UserDto>(id, 'user').subscribe((data) => {
      this.userDto.next(data);
      localStorage.setItem('user', JSON.stringify(data));
      this.role.next(data.roles[0].name);
      this.router.navigate(['dashboard']);
    })
  }

  logOut() {
    localStorage.removeItem('token');
    this.isLoggedIn.next(false);
    localStorage.removeItem('user');
    this.userDto.next({} as any);
    this.role.next({} as any);
    this.router.navigate(['login']);
  }

  get IsLoggedIn(): Observable<boolean>{
    return this.isLoggedIn;
  }

  get Role(): Observable<string>{
    return this.role;
  }

  get User() : UserDto{
    let user = localStorage.getItem('user');
    if (user)
      return JSON.parse(user);
    
    return {} as any;
  }

  get Token() {
    return localStorage.getItem('token');
  }

  get IsAdmin(): boolean {
    if (this.Token && this.User) {
      return this.User.roles?.some((x: any) => x.name === 'Admin');;
    }
    return false;
  }
}
