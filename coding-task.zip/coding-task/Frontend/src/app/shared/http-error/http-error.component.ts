import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-http-error',
  templateUrl: './http-error.component.html',
  styleUrls: ['./http-error.component.scss'],
})
export class HttpErrorComponent implements OnInit, OnDestroy {
  
  errorTitle = '';
  errorText = '';
  subscription: Subscription | undefined;
  constructor(private activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.subscription = this.activatedRoute.params.subscribe((param) => {
      switch (param['errorCode']) {
        case '400':
          this.errorTitle = 'Error 400: Bad Request';
          this.errorText =
            'Something went wrong, please contact your support team.';
          break;
        case '401':
          this.errorTitle = 'Error 401: Unauthorized';
          this.errorText = 'You are not authorized, please login.';
          break;
        case '403':
          this.errorTitle = 'Error 403: Forbidden';
          this.errorText = 'You do not have permission for this action.';
          break;
        case '404':
          this.errorTitle = 'Error 404 : Page Not Found';
          this.errorText =
            'Sorry but the page you are looking for does not exist or is temporarily unavailable.';
          break;
        default:
          this.errorTitle = 'Error 500 : Internal Server Error';
          this.errorText =
            'Something went wrong, please contact your support team.';
          break;
      }
    });
  }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
}
