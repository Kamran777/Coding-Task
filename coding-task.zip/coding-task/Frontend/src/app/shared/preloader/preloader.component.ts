import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoaderService } from '../../services/loader.service';

@Component({
  selector: 'app-preloader',
  templateUrl: './preloader.component.html',
  styleUrls: ['./preloader.component.scss'],
})
export class PreloaderComponent implements OnInit, OnDestroy {
  
  subscription: Subscription;
  isLoading: boolean = true;

  constructor(private loaderService: LoaderService) {
    this.subscription = this.loaderService
      .httpProgress()
      .subscribe((status) => {
        setTimeout(() => {
          this.isLoading = status;
        }, 1000);
      });
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
