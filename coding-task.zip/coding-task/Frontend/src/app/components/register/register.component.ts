import { AuthService } from './../../services/auth.service';
import { Subscription } from 'rxjs';
import { RegisterModel } from 'src/app/models/registerModel';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
declare let alertify: any;

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit, OnDestroy {

  userRegistration: RegisterModel = new RegisterModel();
  subscription: Subscription;
  roless: string[] = ["Admin", "Regular User"];

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    if (this.authService.Token){
      this.router.navigate(['dashboard']);
      return;
    }
  }

  register(form: NgForm){
    if (this.userRegistration && form?.valid) {
      this.subscription = this.authService.register(this.userRegistration).subscribe((data) => {
        form.reset();
        alertify.success("Registration was successfull")
        this.router.navigate(['login']);
      });
    }
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

}
