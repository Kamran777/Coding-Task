import { AuthService } from './../../services/auth.service';
import { ApiService } from './../../services/api.service';
import { Subscription } from 'rxjs';
import { UserDto } from './../../models/userDto';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { LabelType, Options } from '@angular-slider/ngx-slider';
declare let alertify: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit, OnDestroy {

  minValue: any = 0;
  maxValue: any = 100;
  options: Options = {
    floor: 0,
    ceil: 100,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return '' + value;
        case LabelType.High:
          return '' + value;
        default:
          return '' + value;
      }
    },
  };

  
  users: UserDto[];
  user: UserDto;

  firstName: any;
  email: any;
  age: any = 0;
  country: any;

  subscription: Subscription;
  subscriptions: Subscription[] = [];

  isAdmin: boolean;
  p: number = 1;

  constructor(
    private apiService: ApiService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.isAdmin = this.authService.IsAdmin;
    this.load();
  }

  valuechange(newValue:any) {
    this.age = newValue;
  }

  load(): void {
    this.subscription = this.apiService
      .getAll<UserDto[]>(`user`)
      .subscribe((data) => {
        this.users = data;
      });
  }

  logout() {
    this.authService.logOut();
  }

  delete(id: string) {
    this.subscription = this.apiService
      .delete<any>(id, `user`)
      .subscribe((data) => {
        //Message delete
        alertify.success('Deleted successfully');
        this.load();
      });
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
