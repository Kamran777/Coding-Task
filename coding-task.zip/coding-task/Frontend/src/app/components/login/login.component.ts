import { AuthService } from './../../services/auth.service';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationResponse } from 'src/app/models/authenticationResponse';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit, OnDestroy {
  
  loginForm: FormGroup;
  submitted = false;
  token: AuthenticationResponse;
  subscription: Subscription;
  showPassword: boolean;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService, 
    private router: Router
  ) {
    this.showPassword = false;
  }

  ngOnInit(): void {
    if (this.authService.Token){
      this.router.navigate(['dashboard']);
    }
    this.createLoginForm();
  }

  createLoginForm() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.compose([Validators.required, Validators.email])],
      password: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern(
            '(?=.*[A-Za-z])(?=.*[0-9])(?=.*[$@$!#^~%*?&,.<>"\'\\;:{\\}\\[\\]\\|\\+\\-\\=\\_\\)\\(\\)\\`\\/\\\\\\]])[A-Za-z0-9d$@].{7,}'
          ),
        ]),
      ],
    });
  }

  get formControl() {
    return this.loginForm.controls;
  }

  login() {
    this.submitted = true;
    if (this.loginForm.valid) {
      const login = { ...this.loginForm.value };
      this.subscription = this.authService
        .requestToken(login.email, login.password)
        .subscribe((data) => {
          this.authService.completeAuthentication(data.id, data.accessToken);
        });
    }
  }

  showHidePassword(e: any) {
    this.showPassword = e.target.checked;
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }
}
