import { ApiService } from './../../services/api.service';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';
import { UserDto } from './../../models/userDto';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Role } from 'src/app/models/role';
declare let alertify: any;

@Component({
  selector: 'app-update-user-table',
  templateUrl: './update-user-table.component.html',
  styleUrls: ['./update-user-table.component.scss']
})
export class UpdateUserTableComponent implements OnInit, OnDestroy {

  user: UserDto = new UserDto();
  role: Role = new Role();
  roles: Role[] = [];
  
  subscription: Subscription;
  subscriptions: Subscription[] = [];
  
  myPassword: string = "";

  constructor(private activatedRoute: ActivatedRoute, private apiService: ApiService, private router: Router) {
  }

  ngOnInit(): void {
    const id: string = this.activatedRoute.snapshot.params["id"];
    this.subscription = this.apiService.get<UserDto>(id, `user`).subscribe((data) => {
      this.user = data;
      this.role = data.roles[0];
    })
    this.subscription = this.apiService.getAll<Role[]>("user/roles").subscribe((data) => {
      this.roles = data;
    })
  }

  onChangeRole(roleName: string){
    this.role = this.roles.find(x => x.name === roleName)!;
  }


  update(form: NgForm){
    if(!form.invalid){
      if (this.myPassword.length > 0){
        this.user.password = this.myPassword;
      }
      if (this.role){
        this.user.roles = [];
        this.user.roles.push(this.role);
      }
      
      this.apiService.put<any>(this.user.id,`user`,this.user).subscribe((data) => {
        // Message
        alertify.success("Updated successfully");
        this.router.navigate(['dashboard']);
      })
    }
  }

  ngOnDestroy(): void{
    this.subscriptions.forEach((subscription) => subscription.unsubscribe())
  }

}
