import { AuthService } from './../../services/auth.service';
import { Subscription } from 'rxjs';
import { Role } from './../../models/role';
import { UserDto } from './../../models/userDto';
import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit, OnDestroy {
  
  IsLoggedIn: boolean = false;
  role: string = "";
  userDto: UserDto;
  
  subscription: Subscription = new Subscription();
  subscriptions: Subscription[] = [];

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.subscription.add(this.authService.IsLoggedIn.subscribe((data) => {
      this.IsLoggedIn = data;
    }));
    this.subscription.add(this.authService.Role.subscribe(data => {
      this.role = data;
    }))
    
  }

  logout() {
    this.authService.logOut();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
