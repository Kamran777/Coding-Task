import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter',
})
export class FilterPipe implements PipeTransform {
  transform(
    items: any[],
    firstName: string,
    email: string,
    age: number[],
    country: string
  ) {
    if (items && items.length) {
      return items.filter((item: any) => {
        if (
          firstName &&
          item.firstName.toLowerCase().indexOf(firstName.toLowerCase()) === -1
        ) {
          return false;
        }
        if (
          email &&
          item.email.toLowerCase().indexOf(email.toLowerCase()) === -1
        ) {
          return false;
        }
        if (!(age[0] <= item.age && age[1] >= item.age)) {
          return false;
        }
        if (
          country &&
          item.country.toLowerCase().indexOf(country.toLowerCase()) === -1
        ) {
          return false;
        }
        return true;
      });
    } else {
      return items;
    }
  }
}
