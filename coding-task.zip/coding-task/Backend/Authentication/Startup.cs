using System.Text;
using System.Threading.Tasks;
using Authentication.Utils;
using AuthService;
using AuthService.Models;
using DataContext;
using DataContext.Implements;
using DataContext.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Models.Entities;
using Newtonsoft.Json;

namespace Authentication
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IWebHostEnvironment environment)
        {
            Configuration = configuration;
            _environment = environment;
        }
        public IConfiguration Configuration { get; }
        private readonly IWebHostEnvironment _environment;

        public void ConfigureServices(IServiceCollection services)
        {

            #region Cors

            Constants.AngularUrl = Configuration.GetValue<string>("AngularUrl");
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder =>
                {
                    builder.WithOrigins(Constants.AngularUrl.TrimEnd('/')).AllowAnyHeader().AllowAnyMethod();
                });
            });

            #endregion

            #region Db

            var connectionString = Configuration.GetConnectionString("Default");
            services.AddDbContext<AuthDbContext>(options =>
                options.UseSqlServer(connectionString, builder =>
                {
                    builder.MigrationsAssembly(nameof(Authentication));
                }));

            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

            #endregion

            #region Auth

            var authenticationServiceOptions = Configuration.GetSection("AuthConfiguration").Get<AuthenticationServiceOptions>();
            services.AddSingleton(authenticationServiceOptions);

            services.AddIdentity<User, Role>().AddEntityFrameworkStores<AuthDbContext>().AddDefaultTokenProviders();
            services.Configure<DataProtectionTokenProviderOptions>(options => options.TokenLifespan = authenticationServiceOptions.OtpTokenLifespan);
            services.ConfigureApplicationCookie(options => options.ForwardForbid = JwtBearerDefaults.AuthenticationScheme);
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ClockSkew = authenticationServiceOptions.BearerTokenClockSkew,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = authenticationServiceOptions.BearerTokenIssuer,
                    ValidAudience = authenticationServiceOptions.BearerTokenAudience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(authenticationServiceOptions.BearerTokenSecurityKey))
                };
                options.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                            context.Response.Headers.Add("Token-Expired", "true");
                        return Task.CompletedTask;
                    }
                };
            });
            services.AddScoped<AuthenticationService>();

            #endregion

            #region General

            services.Configure<RouteOptions>(options => options.LowercaseUrls = true);
            services.AddControllers().AddNewtonsoftJson(x => x.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore);

            #endregion

            #region Swagger

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "AuthAPI", Version = "v1" });
            });

            #endregion

            services.AddAutoMapper(typeof(AutoMapperProfile));
        }

        public void Configure(IApplicationBuilder app, AuthDbContext dbContext)
        {
            if (_environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                #region Swagger

                if (_environment.IsDevelopment())
                {
                    app.UseSwagger();
                    app.UseSwaggerUI(c =>
                    {
                        c.SwaggerEndpoint("/swagger/v1/swagger.json", "AuthAPI");
                    });
                }

                #endregion
            }
            else
            {
                #region Security Headers

                app.UseHsts(x => x.MaxAge(365).IncludeSubdomains().Preload());
                app.UseXContentTypeOptions();
                app.UseReferrerPolicy(x => x.NoReferrer());
                app.UseXXssProtection(x => x.EnabledWithBlockMode());
                app.UseXfo(x => x.Deny());
                app.UseCsp(x => x
                    .BlockAllMixedContent()
                    .DefaultSources(s => s.Self())
                    .StyleSources(s => s.Self())
                    .StyleSources(s => s.UnsafeInline())
                    .FontSources(s => s.Self())
                    .FormActions(s => s.Self())
                    .FrameAncestors(s => s.Self())
                    .ImageSources(s => s.Self())
                    .ScriptSources(s => s.Self())
                );
                app.UseRedirectValidation();
                app.Use(async (context, next) =>
                {
                    context.Response.Headers.Add("Feature-Policy", "geolocation 'none';midi 'none';notifications 'none';push 'none';sync-xhr 'none';microphone 'none';camera 'none';magnetometer 'none';gyroscope 'none';speaker 'self';vibrate 'none';fullscreen 'self';payment 'none';");
                    await next.Invoke();
                });

                #endregion
            }

            #region Middleware

            app.UseCors("CorsPolicy");
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            #endregion#endregion

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            DataInitializer.SeedData(dbContext);
        }
    }
}
