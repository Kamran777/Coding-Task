﻿
namespace Authentication.Utils
{
    public static class Constants
    {
        public static string AngularUrl { get; set; }
    }
}
