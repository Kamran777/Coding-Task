﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Models.Dto;
using Models.Entities;
using Models.Utils;

namespace Authentication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UserController : ControllerBase
    {

        private readonly UserManager<User> _userManager;
        private readonly RoleManager<Role> _roleManager;
        private readonly IMapper _mapper;

        public UserController(UserManager<User> userManager, IMapper mapper, RoleManager<Role> roleManager)
        {
            _userManager = userManager;
            _mapper = mapper;
            _roleManager = roleManager;
        }

        #region Get Roles

        [HttpGet("roles")]
        [Authorize]
        public IActionResult GetRoles()
        {
            var roles = _roleManager.Roles;

            return Ok(_mapper.Map<IEnumerable<RoleDto>>(roles));
        }

        #endregion

        #region Get All Users

        [HttpGet]
        [Authorize]
        public IActionResult GetAll()
        {
            try
            {
                var userId = HttpContext.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                var data = _userManager.Users.Where(x => x.Id != userId).Include(x => x.UserRoles).ThenInclude(x => x.Role);

                if (data == null || !data.Any())
                    return NotFound();

                var users = _mapper.Map<IEnumerable<UserDto>>(data);

                return Ok(users);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        #endregion

        #region Get User By Id

        [HttpGet("{id}")]
        [Authorize]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            try
            {
                var data = await _userManager.Users.Include(x => x.UserRoles).ThenInclude(x => x.Role).FirstOrDefaultAsync(x => x.Id == id);

                if (data == null)
                    return NotFound();

                var user = _mapper.Map<UserDto>(data);

                return Ok(user);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        #endregion

        #region Update User

        [HttpPut("{id}")]
        [Authorize(Roles = RoleConstants.AdminRole)]
        public async Task<IActionResult> PutUser([FromRoute] string id, [FromBody] UserDto userDto)
        {
            try
            {
                if (id != userDto.Id)
                    return BadRequest();

                if (await _userManager.Users.AnyAsync(x => x.Email.ToLower() == userDto.Email.ToLower() &&
                                                      x.Id != userDto.Id))
                {
                    return BadRequest("The email address is already taken!");
                }

                if (await _userManager.Users.AnyAsync(x => x.UserName.ToLower() == userDto.UserName.ToLower() &&
                                                           x.Id != userDto.Id))
                {
                    return BadRequest("The username is already taken!");
                }

                var dbUser = await _userManager.FindByIdAsync(userDto.Id);
                dbUser.UserName = userDto.UserName;
                dbUser.FirstName = userDto.FirstName;
                dbUser.LastName = userDto.LastName;
                dbUser.Email = userDto.Email;
                dbUser.Roles = _mapper.Map<ICollection<Role>>(userDto.Roles);
                dbUser.Age = userDto.Age;
                dbUser.Country = userDto.Country;

                if (!string.IsNullOrEmpty(userDto.Password))
                    dbUser.PasswordHash = _userManager.PasswordHasher.HashPassword(dbUser, userDto.Password);

                await _userManager.UpdateAsync(dbUser);

                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        #endregion

        #region Delete User

        [HttpDelete("{id}")]
        [Authorize(Roles = RoleConstants.AdminRole)]
        public async Task<IActionResult> DeleteUser([FromRoute] string id)
        {
            try
            {
                var user = await _userManager.FindByIdAsync(id);

                await _userManager.DeleteAsync(user);

                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        #endregion

    }
}
