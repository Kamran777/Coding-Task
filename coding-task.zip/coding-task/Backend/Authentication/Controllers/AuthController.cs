﻿using System;
using System.Security.Authentication;
using System.Threading.Tasks;
using Authentication.Models;
using AuthService;
using AuthService.Exceptions;
using AuthService.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Models.Entities;

namespace Authentication.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly AuthenticationService _authenticationService;

        public AuthController(UserManager<User> userManager, AuthenticationService authenticationService)
        {
            _userManager = userManager;
            _authenticationService = authenticationService;
        }

        #region Register

        [HttpPost]
        public async Task<ActionResult> Register([FromBody] RegisterModel model)
        {
            try
            {
                if (model == null || !ModelState.IsValid)
                    return BadRequest("Please fill out all inputs!");

                if (await _userManager.FindByEmailAsync(model.Email) != null)
                {
                    return BadRequest("The email address is already taken!");
                }

                if (await _userManager.FindByNameAsync(model.UserName) != null)
                {
                    return BadRequest("The username is already taken!");
                }

                var user = new User
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    UserName = model.UserName,
                    Age = model.Age,
                    Country = model.Country
                };

                var result = await _userManager.CreateAsync(user, model.Password);
                await _userManager.AddToRoleAsync(user, model.Role.ToString());

                if (result.Succeeded)
                {
                    return Ok(result);
                }

                return BadRequest(result.Errors);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Unexpected exception: {ex.Message}.");
            }
        }

        #endregion

        #region Login

        [HttpPost]
        public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
        {
            try
            {
                var result = await _authenticationService.AuthenticateAsync(new AuthenticationRequest
                    {Email = loginModel.Email, Password = loginModel.Password});

                return Ok(result);
            }
            catch (AuthenticationServiceForbiddenException ex)
            {
                return Forbid(ex.Message);
            }
            catch (AuthenticationServiceUnauthorizedException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (InvalidCredentialException ex)
            {
                return Unauthorized(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Unexpected exception: {ex.Message}.");
            }
        }

        #endregion
    }
}
