﻿
namespace Models.Utils
{
    public static class RoleConstants
    {
        public const string AdminRole = "Admin";
        public const string RegularUserRole = "Regular User";
    }
}
