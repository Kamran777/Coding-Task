﻿using Models.Interfaces;

namespace Models.Dto
{
    public class UserRoleDto : IDto
    {
        public string Id { get; set; }

        public UserDto User { get; set; }

        public RoleDto Role { get; set; }
    }
}
