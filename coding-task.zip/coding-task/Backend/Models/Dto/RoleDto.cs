﻿using System.ComponentModel.DataAnnotations;
using Models.Interfaces;

namespace Models.Dto
{
    public class RoleDto : IDto
    {
        public string Id { get; set; }

        [Required]
        public string Name { get; set; }
    }
}
