﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;
using Models.Utils;
using Newtonsoft.Json;


namespace Models.Entities
{
    public class User : IdentityUser
    {
        public User()
        {
            Roles = new JoinCollectionFacade<Role, UserRole>(
                UserRoles,
                ur => ur.Role,
                r => new UserRole { User = this, Role = r }
            );
        }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [DefaultValue(true)]
        public bool IsEnabled { get; set; } = true;

        [Required]
        public override string UserName { get; set; }

        public ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();

        [NotMapped, JsonIgnore]
        public ICollection<Role> Roles { get; set; }

        [Required]
        public int Age { get; set; }

        [Required]
        public string Country { get; set; }
    }
}
