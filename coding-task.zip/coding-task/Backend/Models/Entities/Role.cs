﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json;

namespace Models.Entities
{
    public class Role : IdentityRole
    {
        [Required]
        public override string Name { get; set; }

        public ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();

        [NotMapped, JsonIgnore]
        public ICollection<User> Users { get; set; }
    }
}
