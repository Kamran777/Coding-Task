﻿
namespace Models.Interfaces
{
    public interface IDbEntity
    {
        int Id { get; set; }
    }
}
