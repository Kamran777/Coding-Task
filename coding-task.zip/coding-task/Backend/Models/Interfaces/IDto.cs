﻿
namespace Models.Interfaces
{
    public interface IDto
    {
        string Id { get; set; }
    }
}
