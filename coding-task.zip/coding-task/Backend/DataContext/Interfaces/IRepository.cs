﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Query;

namespace DataContext.Interfaces
{
    public interface IRepository<TDbEntity> where TDbEntity : class
    {
        IQueryable<TDbEntity> GetAll(Expression<Func<TDbEntity, bool>> expression = null,
            Func<IQueryable<TDbEntity>, IIncludableQueryable<TDbEntity, object>> include = null, bool tracking = false);
        Task<TDbEntity> GetAsync(Expression<Func<TDbEntity, bool>> expression,
            Func<IQueryable<TDbEntity>, IIncludableQueryable<TDbEntity, object>> include = null, bool tracking = false);
        Task<bool> AddAsync(TDbEntity entity);
        Task<bool> AddAsync(IEnumerable<TDbEntity> entities);
        Task<bool> AddAsync(params TDbEntity[] entities);
        Task<bool> UpdateAsync(TDbEntity entity);
        Task<bool> UpdateAsync(IEnumerable<TDbEntity> entities);
        Task<bool> UpdateAsync(params TDbEntity[] entities);
        Task<bool> DeleteAsync(TDbEntity entity);
        Task<bool> DeleteAsync(IEnumerable<TDbEntity> entities);
    }
}
