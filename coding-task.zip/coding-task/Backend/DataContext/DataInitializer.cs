﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Models.Entities;
using Models.Utils;

namespace DataContext
{
    public class DataInitializer
    {
        public static void SeedData(AuthDbContext db)
        {
            db.Database.Migrate();

            using var dbContextTransaction = db.Database.BeginTransaction();
            try
            {
                #region Role seed

                var roles = new List<string> { RoleConstants.AdminRole, RoleConstants.RegularUserRole };
                foreach (var roleValue in roles)
                {
                    if (db.Roles.Any(x => x.Name.ToLower() == roleValue.ToLower()))
                        continue;

                    var role = new Role { Name = roleValue, NormalizedName = roleValue};
                    db.Roles.Add(role);
                    db.SaveChanges();
                }

                #endregion

                dbContextTransaction.Commit();
            }
            catch (Exception)
            {
                dbContextTransaction.Rollback();
            }
        }
    }
}
