﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using DataContext.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;

namespace DataContext.Implements
{
    public class Repository<TDbEntity> : IRepository<TDbEntity> where TDbEntity : class
    {
        protected AuthDbContext Db;

        public Repository(AuthDbContext db)
        {
            Db = db;
        }

        public IQueryable<TDbEntity> GetAll(Expression<Func<TDbEntity, bool>> expression = null, Func<IQueryable<TDbEntity>, IIncludableQueryable<TDbEntity, object>> include = null, bool tracking = false)
        {
            try
            {
                IQueryable<TDbEntity> query = Db.Set<TDbEntity>();
                if (!tracking)
                    query.AsNoTracking();

                if (include != null)
                    query = include(query);

                if (expression != null)
                    query = query.Where(expression);

                return query;
            }
            catch
            {
                // Writing to log will be here
            }

            return null;
        }

        public async Task<TDbEntity> GetAsync(Expression<Func<TDbEntity, bool>> expression, Func<IQueryable<TDbEntity>, IIncludableQueryable<TDbEntity, object>> include = null, bool tracking = false)
        {
            try
            {
                return await GetAll(expression, include, tracking).FirstOrDefaultAsync();
            }
            catch
            {
                // Writing to log will be here
            }

            return null;
        }

        public virtual async Task UpdateStatesAsync(TDbEntity entity, EntityState state)
        {
            Db.Entry(entity).State = state;
            await Db.SaveChangesAsync();
        }

        public async Task<bool> AddAsync(TDbEntity entity)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                await UpdateStatesAsync(entity, EntityState.Added);
                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch (Exception)
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }

        public async Task<bool> AddAsync(IEnumerable<TDbEntity> entities)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                foreach (var entity in entities)
                    await UpdateStatesAsync(entity, EntityState.Added);

                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch (Exception)
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }

        public async Task<bool> AddAsync(params TDbEntity[] entities)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                foreach (var entity in entities)
                    await UpdateStatesAsync(entity, EntityState.Added);

                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch (Exception)
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }

        public async Task<bool> UpdateAsync(TDbEntity entity)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                await UpdateStatesAsync(entity, EntityState.Modified);
                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }

        public async Task<bool> UpdateAsync(IEnumerable<TDbEntity> entities)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                foreach (var entity in entities)
                    await UpdateStatesAsync(entity, EntityState.Modified);

                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }

        public async Task<bool> UpdateAsync(params TDbEntity[] entities)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                foreach (var entity in entities)
                    await UpdateStatesAsync(entity, EntityState.Modified);

                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }

        public async Task<bool> DeleteAsync(TDbEntity entity)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                await UpdateStatesAsync(entity, EntityState.Deleted);
                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }

        public async Task<bool> DeleteAsync(IEnumerable<TDbEntity> entities)
        {
            await using var dbContextTransaction = await Db.Database.BeginTransactionAsync();
            try
            {
                foreach (var entity in entities)
                    await UpdateStatesAsync(entity, EntityState.Deleted);

                await dbContextTransaction.CommitAsync();
                return true;
            }
            catch
            {
                await dbContextTransaction.RollbackAsync();
            }

            return false;
        }
    }
}
