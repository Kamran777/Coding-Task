﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Authentication;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AuthService.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using AuthService.Exceptions;
using Models.Entities;

namespace AuthService
{
    public class AuthenticationService
    {
        #region Fields

        private readonly AuthenticationServiceOptions _options;
        private readonly UserManager<User> _userManager;

        #endregion

        #region Constructors

        public AuthenticationService(AuthenticationServiceOptions options, UserManager<User> userManager)
        {
            _options = options;
            _userManager = userManager;
        }

        #endregion

        #region Methods

        public async Task<AuthenticationResponse> AuthenticateAsync(AuthenticationRequest request)
        {
            var user = await _userManager.FindByEmailAsync(request.Email);
            if (user == null)
            {
                throw new AuthenticationServiceUnauthorizedException("User not found.");
            }

            if (!user.IsEnabled)
            {
                throw new AuthenticationServiceForbiddenException("User is disabled.");
            }

            if (!await _userManager.CheckPasswordAsync(user, request.Password))
            {
                throw new InvalidCredentialException("User or password is invalid.");
            }

            return new AuthenticationResponse
            {
                AccessToken = await GetAccessTokenForUser(user),
                Id = user.Id,
            };
        }

        public ClaimsPrincipal GetPrincipalFromAccessToken(string accessToken)
        {
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = false,
                ValidateIssuerSigningKey = true,
                ValidIssuer = _options.BearerTokenIssuer,
                ValidAudience = _options.BearerTokenAudience,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.BearerTokenSecurityKey))
            };

            ClaimsPrincipal principal = null;

            try
            {
                principal = new JwtSecurityTokenHandler().ValidateToken(accessToken, tokenValidationParameters, out var securityToken);
                if (!(securityToken is JwtSecurityToken jwtSecurityToken) ||
                    !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                    return null;
            }
            catch (Exception)
            {
                // If for any reason we can't validate our access token let's just return null.
            }

            return principal;
        }

        private async Task<string> GetAccessTokenForUser(User user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim(ClaimTypes.Name, user.FirstName),
                new Claim(ClaimTypes.Surname, user.LastName),
                new Claim("iss", _options.BearerTokenIssuer)
            };
            var roles = await _userManager.GetRolesAsync(user);
            claims.AddRange(roles.Select(role => new Claim(ClaimTypes.Role, role)));

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.BearerTokenSecurityKey));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var jwtToken = new JwtSecurityToken(_options.BearerTokenIssuer, _options.BearerTokenAudience, claims,
                DateTime.UtcNow, DateTime.UtcNow.Add(_options.BearerAccessTokenLifespan), credentials);

            return new JwtSecurityTokenHandler().WriteToken(jwtToken);
        }

        #endregion
    }
}
