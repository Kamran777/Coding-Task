﻿
namespace AuthService.Models
{
    public class AuthenticationResponse
    {
        public string Id { get; set; }

        public string AccessToken { get; set; }
    }
}
