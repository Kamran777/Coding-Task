﻿
namespace AuthService.Exceptions
{
    public class AuthenticationServiceForbiddenException : System.Exception
    {
        public AuthenticationServiceForbiddenException() { }

        public AuthenticationServiceForbiddenException(string message) : base(message) { }

        public AuthenticationServiceForbiddenException(string message, System.Exception innerException) : base(message, innerException) { }
    }
}
