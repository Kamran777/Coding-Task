﻿
namespace AuthService.Exceptions
{
    public class AuthenticationServiceUnauthorizedException : System.Exception
    {
        public AuthenticationServiceUnauthorizedException() { }

        public AuthenticationServiceUnauthorizedException(string message) : base(message) { }

        public AuthenticationServiceUnauthorizedException(string message, System.Exception innerException) : base(message, innerException) { }
    }
}
